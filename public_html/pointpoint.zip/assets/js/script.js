$(function(){
	
	var pp = $('#push').pointPoint();
	
	// To destroy it, call the destroy method:
	// pp.destroyPointPoint(); 	
	
});